import os, shutil, cv2
from pathlib import Path

# 原始目录
IMG_DIR = Path(r"data/images")
MSK_DIR = Path(r"data/masks")

# 输出目录（新的“成对”数据）
OUT_IMG = Path(r"data/images_paired")
OUT_MSK = Path(r"data/masks_paired")
OUT_IMG.mkdir(parents=True, exist_ok=True)
OUT_MSK.mkdir(parents=True, exist_ok=True)

ex_img = {p.stem.lower(): p for p in IMG_DIR.iterdir() if p.suffix.lower() in [".png", ".jpg", ".jpeg"]}
ex_msk = {p.stem.lower(): p for p in MSK_DIR.iterdir() if p.suffix.lower() in [".png", ".jpg", ".jpeg"]}

def strip_mask(name: str) -> str:
    # 把 *_mask 去掉，得到与图像一致的基名
    return name.replace("_mask", "")

pairs = []
for mstem, mpath in ex_msk.items():
    base = strip_mask(mstem)
    if base in ex_img:
        pairs.append((ex_img[base], mpath, base))

print(f"found pairs: {len(pairs)}")

copied = 0
for ipath, mpath, base in pairs:
    # 复制图像
    dst_img = OUT_IMG / (base + ipath.suffix.lower())
    shutil.copy2(ipath, dst_img)

    # 读取并二值化 mask（>0 -> 255），保存为 PNG，文件名与图像基名一致
    m = cv2.imread(str(mpath), cv2.IMREAD_GRAYSCALE)
    if m is None:
        continue
    m_bin = (m > 0).astype("uint8") * 255
    dst_msk = OUT_MSK / (base + ".png")
    cv2.imwrite(str(dst_msk), m_bin)
    copied += 1

print(f"copied pairs: {copied}")
print(f"output dirs:\n  {OUT_IMG}\n  {OUT_MSK}")
