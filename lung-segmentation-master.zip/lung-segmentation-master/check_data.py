import os, sys
IMG_DIR = r"data\images"
MSK_DIR = r"data\masks"
imgs = sorted([os.path.splitext(f)[0] for f in os.listdir(IMG_DIR) if f.lower().endswith(('.png','.jpg','.jpeg'))])
msks = sorted([os.path.splitext(f)[0] for f in os.listdir(MSK_DIR) if f.lower().endswith(('.png','.jpg','.jpeg'))])

si, sm = set(imgs), set(msks)
missing_masks = sorted(si - sm)
missing_images = sorted(sm - si)

print(f"images: {len(imgs)}, masks: {len(msks)}")
print("missing masks:", len(missing_masks))
print("missing images:", len(missing_images))
if missing_masks[:8]: print("examples (img no mask):", missing_masks[:8])
if missing_images[:8]: print("examples (mask no img):", missing_images[:8])
