#!/usr/bin/env python3
"""
Baseline训练脚本 - 肺部分割
基于简单U-Net架构进行baseline训练
"""

import torch
import torchvision
import os
import time 
import pickle
import argparse

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split

from src.data import LungDataset, blend, Pad, Crop, Resize
from src.models import UNet
from src.metrics import jaccard, dice

def main():
    # 参数设置
    parser = argparse.ArgumentParser(description='肺部分割 Baseline 训练')
    parser.add_argument('--epochs', type=int, default=15, help='训练轮数 (默认: 15)')
    parser.add_argument('--batch_size', type=int, default=4, help='批量大小 (默认: 4)')
    parser.add_argument('--lr', type=float, default=0.001, help='学习率 (默认: 0.001)')
    parser.add_argument('--model_name', type=str, default='unet-15epochs.pt', help='模型保存名称')
    parser.add_argument('--use_cuda', action='store_true', help='使用CUDA (如果可用)')
    
    args = parser.parse_args()
    
    # 设备设置
    if args.use_cuda and torch.cuda.is_available():
        device = torch.device("cuda:0")
        print(f"使用GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("使用CPU")
    
    # 路径设置
    data_folder = Path("data")
    origins_folder = data_folder / "images"
    masks_folder = data_folder / "masks"
    models_folder = Path("models")
    models_folder.mkdir(exist_ok=True)
    
    print(f"数据路径: {data_folder}")
    print(f"图像路径: {origins_folder}")
    print(f"掩码路径: {masks_folder}")
    
    # 数据加载
    print("加载数据...")
    origins_list = [f.stem for f in origins_folder.glob("*.png")]
    masks_list = [f.stem for f in masks_folder.glob("*.png")]
    
    print(f"找到 {len(origins_list)} 张原始图像")
    print(f"找到 {len(masks_list)} 张掩码图像")
    
    # 创建配对列表
    origin_mask_list = [(mask_name.replace("_mask", ""), mask_name) for mask_name in masks_list]
    
    # 数据分割
    split_file = "splits.pk"
    if os.path.isfile(split_file):
        with open("splits.pk", "rb") as f:
            splits = pickle.load(f)
        print("从已保存的splits.pk加载数据分割")
    else:
        splits = {}
        splits["train"], splits["test"] = train_test_split(origin_mask_list, test_size=0.2, random_state=42)
        splits["train"], splits["val"] = train_test_split(splits["train"], test_size=0.1, random_state=42)

        with open("splits.pk", "wb") as f:
            pickle.dump(splits, f)
        print("创建新的数据分割并保存到splits.pk")
    
    print(f"训练集: {len(splits['train'])} 张")
    print(f"验证集: {len(splits['val'])} 张")
    print(f"测试集: {len(splits['test'])} 张")
    
    # 数据变换 - Baseline使用简单的resize
    simple_transforms = torchvision.transforms.Compose([
        Resize((256, 256)),  # 恢复为原始分辨率
    ])
    
    # 创建数据集
    datasets = {x: LungDataset(
        splits[x], 
        origins_folder, 
        masks_folder, 
        simple_transforms
    ) for x in ["train", "test", "val"]}
    
    dataloaders = {x: torch.utils.data.DataLoader(
        datasets[x], 
        batch_size=args.batch_size,
        shuffle=(x == "train")
    ) for x in ["train", "test", "val"]}
    
    # 创建模型 - 简单的U-Net作为baseline
    print("创建基线U-Net模型...")
    model = UNet(in_channels=1, out_channels=2, batch_norm=False)
    model = model.to(device)
    
    # 优化器和损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    
    # 训练循环
    print(f"开始训练 {args.epochs} 个epoch...")
    train_log_filename = f"train-log-baseline.txt"
    best_val_loss = np.inf
    history = []
    
    # 清空之前的训练日志
    if os.path.exists(train_log_filename):
        os.remove(train_log_filename)
    
    for epoch in range(args.epochs):
        start_time = time.time()
        
        # 训练阶段
        print(f"\nEpoch {epoch+1}/{args.epochs}")
        print("训练阶段...")
        model.train()
        train_loss = 0.0
        train_samples = 0
        
        for batch_idx, (origins, masks) in enumerate(dataloaders["train"]):
            num = origins.size(0)
            
            origins = origins.to(device)
            masks = masks.to(device)
            
            optimizer.zero_grad()
            
            outputs = model(origins)
            softmax = torch.nn.functional.log_softmax(outputs, dim=1)
            loss = torch.nn.functional.nll_loss(softmax, masks)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item() * num
            train_samples += num
            
            if (batch_idx + 1) % 10 == 0:
                print(f"  Batch {batch_idx+1}/{len(dataloaders['train'])}, Loss: {loss.item():.4f}")
        
        train_loss = train_loss / train_samples
        
        # 验证阶段
        print("验证阶段...")
        model.eval()
        val_loss = 0.0
        val_jaccard = 0.0
        val_dice = 0.0
        val_samples = 0
        
        with torch.no_grad():
            for origins, masks in dataloaders["val"]:
                num = origins.size(0)
                
                origins = origins.to(device)
                masks = masks.to(device)
                
                outputs = model(origins)
                softmax = torch.nn.functional.log_softmax(outputs, dim=1)
                val_loss += torch.nn.functional.nll_loss(softmax, masks).item() * num
                
                predictions = torch.argmax(softmax, dim=1)
                predictions = predictions.float()
                masks_float = masks.float()
                
                val_jaccard += jaccard(masks_float, predictions).item() * num
                val_dice += dice(masks_float, predictions).item() * num
                val_samples += num
        
        val_loss = val_loss / val_samples
        val_jaccard = val_jaccard / val_samples
        val_dice = val_dice / val_samples
        
        end_time = time.time()
        epoch_time = end_time - start_time
        
        # 记录训练历史
        epoch_info = {
            "epoch": epoch + 1,
            "time": epoch_time,
            "train_loss": train_loss,
            "val_loss": val_loss,
            "val_jaccard": val_jaccard,
            "val_dice": val_dice,
        }
        history.append(epoch_info)
        
        # 输出训练信息
        report = f"Epoch: {epoch+1}/{args.epochs}, Time: {epoch_time:.2f}s, " \
               f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, " \
               f"Val Jaccard: {val_jaccard:.4f}, Val Dice: {val_dice:.4f}"
        
        print(report)
        
        # 保存训练日志
        with open(train_log_filename, "a") as f:
            f.write(report + "\n")
        
        # 保存最佳模型
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), models_folder / args.model_name)
            print("✓ 保存最佳模型")
            with open(train_log_filename, "a") as f:
                f.write("模型已保存\n")
    
    print(f"\n训练完成! 最佳验证损失: {best_val_loss:.4f}")
    
    # 测试阶段
    print("\n在测试集上评估...")
    model.load_state_dict(torch.load(models_folder / args.model_name))
    model.eval()
    
    test_loss = 0.0
    test_jaccard = 0.0
    test_dice = 0.0
    test_samples = 0
    
    with torch.no_grad():
        for origins, masks in dataloaders["test"]:
            num = origins.size(0)
            
            origins = origins.to(device)
            masks = masks.to(device)
            
            outputs = model(origins)
            softmax = torch.nn.functional.log_softmax(outputs, dim=1)
            test_loss += torch.nn.functional.nll_loss(softmax, masks).item() * num
            
            predictions = torch.argmax(softmax, dim=1)
            predictions = predictions.float()
            masks_float = masks.float()
            
            test_jaccard += jaccard(masks_float, predictions).item() * num
            test_dice += dice(masks_float, predictions).item() * num
            test_samples += num
    
    test_loss = test_loss / test_samples
    test_jaccard = test_jaccard / test_samples
    test_dice = test_dice / test_samples
    
    print(f"\n=== 最终测试结果 ===")
    print(f"测试损失: {test_loss:.4f}")
    print(f"测试Jaccard: {test_jaccard:.4f}")
    print(f"测试Dice: {test_dice:.4f}")
    
    # 保存最终结果
    final_results = f"\n=== 最终测试结果 ===\n" \
                   f"测试损失: {test_loss:.4f}\n" \
                   f"测试Jaccard: {test_jaccard:.4f}\n" \
                   f"测试Dice: {test_dice:.4f}\n"
    
    with open(train_log_filename, "a") as f:
        f.write(final_results)
    
    # 绘制训练曲线
    if len(history) > 1:
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        epochs = [h["epoch"] for h in history]
        train_losses = [h["train_loss"] for h in history]
        val_losses = [h["val_loss"] for h in history]
        
        plt.plot(epochs, train_losses, 'b-', label='训练损失')
        plt.plot(epochs, val_losses, 'r-', label='验证损失')
        plt.xlabel('Epoch')
        plt.ylabel('损失')
        plt.legend()
        plt.title('训练和验证损失')
        
        plt.subplot(1, 2, 2)
        val_dices = [h["val_dice"] for h in history]
        val_jaccards = [h["val_jaccard"] for h in history]
        
        plt.plot(epochs, val_dices, 'g-', label='Dice分数')
        plt.plot(epochs, val_jaccards, 'orange', label='Jaccard分数')
        plt.xlabel('Epoch')
        plt.ylabel('分数')
        plt.legend()
        plt.title('验证指标')
        
        plt.tight_layout()
        plt.savefig(f'baseline_training_curves.png', dpi=150, bbox_inches='tight')
        print(f"训练曲线已保存到 baseline_training_curves.png")
    
    print("Baseline训练完成!")

if __name__ == "__main__":
    main()