#!/usr/bin/env python3
"""
Baseline模型推理脚本
用于测试训练好的肺部分割模型
"""

import torch
import torchvision
import argparse
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image

from src.data import LungDataset, blend, Resize
from src.models import UNet
from src.metrics import jaccard, dice

def load_model(model_path, device):
    """加载训练好的模型"""
    model = UNet(in_channels=1, out_channels=2, batch_norm=False)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model = model.to(device)
    model.eval()
    return model

def preprocess_image(image_path, target_size=(256, 256)):
    """预处理单张图像"""
    image = Image.open(image_path).convert("P")
    resize_transform = Resize(target_size)
    # 创建一个虚拟的mask用于transform
    dummy_mask = Image.new("L", image.size, 0)
    image, _ = resize_transform((image, dummy_mask))
    
    # 转换为tensor并归一化
    image_tensor = torchvision.transforms.functional.to_tensor(image) - 0.5
    return image_tensor.unsqueeze(0)  # 添加batch维度

def predict_single_image(model, image_tensor, device):
    """对单张图像进行预测"""
    image_tensor = image_tensor.to(device)
    
    with torch.no_grad():
        outputs = model(image_tensor)
        softmax = torch.nn.functional.log_softmax(outputs, dim=1)
        prediction = torch.argmax(softmax, dim=1)
    
    return prediction.squeeze(0)  # 移除batch维度

def visualize_result(original_image, prediction, save_path=None):
    """可视化预测结果"""
    plt.figure(figsize=(15, 5))
    
    # 原始图像
    plt.subplot(1, 3, 1)
    original_pil = torchvision.transforms.functional.to_pil_image(original_image + 0.5).convert("RGB")
    plt.imshow(np.array(original_pil))
    plt.title("原始图像")
    plt.axis('off')
    
    # 预测掩码
    plt.subplot(1, 3, 2)
    prediction_pil = torchvision.transforms.functional.to_pil_image(prediction.float())
    plt.imshow(np.array(prediction_pil), cmap='gray')
    plt.title("预测掩码")
    plt.axis('off')
    
    # 叠加显示
    plt.subplot(1, 3, 3)
    blended = blend(original_image, prediction)
    plt.imshow(np.array(blended))
    plt.title("叠加显示")
    plt.axis('off')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"结果已保存到: {save_path}")
    
    plt.show()

def main():
    parser = argparse.ArgumentParser(description='肺部分割 Baseline 推理')
    parser.add_argument('--model_path', type=str, default='models/unet-baseline.pt', 
                       help='模型路径')
    parser.add_argument('--image_path', type=str, 
                       help='要预测的图像路径')
    parser.add_argument('--output_path', type=str, default='prediction_result.png',
                       help='输出结果路径')
    parser.add_argument('--use_cuda', action='store_true', help='使用CUDA (如果可用)')
    
    args = parser.parse_args()
    
    # 设备设置
    if args.use_cuda and torch.cuda.is_available():
        device = torch.device("cuda:0")
        print(f"使用GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("使用CPU")
    
    # 加载模型
    print(f"加载模型: {args.model_path}")
    model = load_model(args.model_path, device)
    
    # 如果没有指定图像路径，使用测试数据集中的一张图像
    if not args.image_path:
        data_folder = Path("data/images")
        image_files = list(data_folder.glob("*.png"))
        if len(image_files) > 0:
            args.image_path = str(image_files[0])  # 使用第一张图像
            print(f"使用测试图像: {args.image_path}")
        else:
            print("错误: 没有找到测试图像，请指定 --image_path")
            return
    
    # 预处理图像
    print(f"处理图像: {args.image_path}")
    image_tensor = preprocess_image(args.image_path)
    
    # 进行预测
    print("进行预测...")
    prediction = predict_single_image(model, image_tensor, device)
    
    # 可视化结果
    visualize_result(image_tensor.squeeze(0), prediction, args.output_path)
    
    print("推理完成!")

if __name__ == "__main__":
    main()