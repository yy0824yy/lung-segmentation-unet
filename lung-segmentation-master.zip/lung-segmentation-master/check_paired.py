import os
IMG_DIR = r"data\images_paired"
MSK_DIR = r"data\masks_paired"
imgs = [f for f in os.listdir(IMG_DIR) if f.lower().endswith(('.png','.jpg','.jpeg'))]
msks = [f for f in os.listdir(MSK_DIR) if f.lower().endswith(('.png','.jpg','.jpeg'))]
print("images_paired:", len(imgs), "masks_paired:", len(msks))
missing = set(os.path.splitext(f)[0] for f in imgs) ^ set(os.path.splitext(f)[0] for f in msks)
print("mismatch:", len(missing))
