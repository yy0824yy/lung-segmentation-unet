#!/usr/bin/env python3
"""
改进版肺部分割训练脚本
基于baseline结果的优化版本
"""

import torch
import torchvision
import os
import time 
import pickle
import argparse
import numpy as np
import matplotlib.pyplot as plt

from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split

from src.data import LungDataset, blend, Pad, Crop, Resize
from src.models import UNet
from src.metrics import jaccard, dice

class DiceLoss(torch.nn.Module):
    """Dice Loss实现"""
    def __init__(self, smooth=1.0):
        super(DiceLoss, self).__init__()
        self.smooth = smooth
    
    def forward(self, pred, target):
        pred = torch.softmax(pred, dim=1)[:, 1]  # 取前景概率
        target = target.float()
        
        intersection = (pred * target).sum()
        dice_coeff = (2.0 * intersection + self.smooth) / (pred.sum() + target.sum() + self.smooth)
        return 1.0 - dice_coeff

def main():
    parser = argparse.ArgumentParser(description='肺部分割 改进版训练')
    parser.add_argument('--epochs', type=int, default=30, help='训练轮数 (默认: 30)')
    parser.add_argument('--batch_size', type=int, default=4, help='批量大小 (默认: 4)')
    parser.add_argument('--lr', type=float, default=0.001, help='初始学习率 (默认: 0.001)')
    parser.add_argument('--img_size', type=int, default=512, help='图像尺寸 (默认: 512)')
    parser.add_argument('--use_bn', action='store_true', help='使用批量归一化')
    parser.add_argument('--use_augment', action='store_true', help='使用数据增强')
    parser.add_argument('--use_dice_loss', action='store_true', help='使用Dice损失函数')
    parser.add_argument('--model_name', type=str, default='unet-improved.pt', help='模型保存名称')
    parser.add_argument('--use_cuda', action='store_true', help='使用CUDA')
    
    args = parser.parse_args()
    
    # 设备设置
    if args.use_cuda and torch.cuda.is_available():
        device = torch.device("cuda:0")
        print(f"使用GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("使用CPU")
    
    # 路径设置
    data_folder = Path("data")
    origins_folder = data_folder / "images"
    masks_folder = data_folder / "masks"
    models_folder = Path("models")
    models_folder.mkdir(exist_ok=True)
    
    print(f"\n=== 训练配置 ===")
    print(f"训练轮数: {args.epochs}")
    print(f"批量大小: {args.batch_size}")
    print(f"学习率: {args.lr}")
    print(f"图像尺寸: {args.img_size}×{args.img_size}")
    print(f"批量归一化: {'是' if args.use_bn else '否'}")
    print(f"数据增强: {'是' if args.use_augment else '否'}")
    print(f"Dice损失: {'是' if args.use_dice_loss else '否'}")
    
    # 数据加载
    print("\n=== 数据加载 ===")
    origins_list = [f.stem for f in origins_folder.glob("*.png")]
    masks_list = [f.stem for f in masks_folder.glob("*.png")]
    
    print(f"找到 {len(origins_list)} 张原始图像")
    print(f"找到 {len(masks_list)} 张掩码图像")
    
    origin_mask_list = [(mask_name.replace("_mask", ""), mask_name) for mask_name in masks_list]
    
    # 数据分割
    split_file = "splits.pk"
    if os.path.isfile(split_file):
        with open("splits.pk", "rb") as f:
            splits = pickle.load(f)
        print("使用已保存的数据分割")
    else:
        splits = {}
        splits["train"], splits["test"] = train_test_split(origin_mask_list, test_size=0.2, random_state=42)
        splits["train"], splits["val"] = train_test_split(splits["train"], test_size=0.1, random_state=42)
        with open("splits.pk", "wb") as f:
            pickle.dump(splits, f)
        print("创建新的数据分割")
    
    print(f"训练集: {len(splits['train'])} 张")
    print(f"验证集: {len(splits['val'])} 张") 
    print(f"测试集: {len(splits['test'])} 张")
    
    # 数据变换
    val_test_transforms = torchvision.transforms.Compose([
        Resize((args.img_size, args.img_size)),
    ])
    
    if args.use_augment:
        train_transforms = torchvision.transforms.Compose([
            Pad(50),  # 随机填充
            Crop(100),  # 随机裁剪
            Resize((args.img_size, args.img_size)),
        ])
        print("启用数据增强")
    else:
        train_transforms = val_test_transforms
        print("不使用数据增强")
    
    # 创建数据集
    datasets = {x: LungDataset(
        splits[x], 
        origins_folder, 
        masks_folder, 
        train_transforms if x == "train" else val_test_transforms
    ) for x in ["train", "test", "val"]}
    
    dataloaders = {x: torch.utils.data.DataLoader(
        datasets[x], 
        batch_size=args.batch_size,
        shuffle=(x == "train"),
        num_workers=0  # Windows系统建议设为0
    ) for x in ["train", "test", "val"]}
    
    # 创建模型
    print(f"\n=== 模型配置 ===")
    model = UNet(in_channels=1, out_channels=2, batch_norm=args.use_bn)
    model = model.to(device)
    print(f"网络参数量: {sum(p.numel() for p in model.parameters()):,}")
    
    # 优化器和损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    
    # 学习率调度器
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=args.lr*0.01
    )
    
    # 损失函数
    if args.use_dice_loss:
        criterion = DiceLoss()
        print("使用Dice损失函数")
    else:
        print("使用交叉熵损失函数")
    
    # 训练循环
    print(f"\n=== 开始训练 ===")
    train_log_filename = f"train-log-improved.txt"
    best_val_loss = np.inf
    best_val_dice = 0.0
    history = []
    
    # 清空训练日志
    if os.path.exists(train_log_filename):
        os.remove(train_log_filename)
    
    for epoch in range(args.epochs):
        start_time = time.time()
        
        # 训练阶段
        print(f"\nEpoch {epoch+1}/{args.epochs} (LR: {scheduler.get_last_lr()[0]:.6f})")
        print("训练阶段...")
        model.train()
        train_loss = 0.0
        train_samples = 0
        
        for batch_idx, (origins, masks) in enumerate(dataloaders["train"]):
            num = origins.size(0)
            origins = origins.to(device)
            masks = masks.to(device)
            
            optimizer.zero_grad()
            
            outputs = model(origins)
            
            if args.use_dice_loss:
                loss = criterion(outputs, masks)
            else:
                softmax = torch.nn.functional.log_softmax(outputs, dim=1)
                loss = torch.nn.functional.nll_loss(softmax, masks)
            
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item() * num
            train_samples += num
            
            if (batch_idx + 1) % 20 == 0:
                print(f"  Batch {batch_idx+1}/{len(dataloaders['train'])}, Loss: {loss.item():.4f}")
        
        train_loss = train_loss / train_samples
        
        # 验证阶段
        print("验证阶段...")
        model.eval()
        val_loss = 0.0
        val_jaccard = 0.0
        val_dice = 0.0
        val_samples = 0
        
        with torch.no_grad():
            for origins, masks in dataloaders["val"]:
                num = origins.size(0)
                origins = origins.to(device)
                masks = masks.to(device)
                
                outputs = model(origins)
                
                if args.use_dice_loss:
                    val_loss += criterion(outputs, masks).item() * num
                else:
                    softmax = torch.nn.functional.log_softmax(outputs, dim=1)
                    val_loss += torch.nn.functional.nll_loss(softmax, masks).item() * num
                    outputs = torch.argmax(softmax, dim=1)
                
                if not args.use_dice_loss:
                    predictions = outputs.float()
                else:
                    predictions = torch.argmax(torch.softmax(outputs, dim=1), dim=1).float()
                
                masks_float = masks.float()
                val_jaccard += jaccard(masks_float, predictions).item() * num
                val_dice += dice(masks_float, predictions).item() * num
                val_samples += num
        
        val_loss = val_loss / val_samples
        val_jaccard = val_jaccard / val_samples
        val_dice = val_dice / val_samples
        
        # 更新学习率
        scheduler.step()
        
        end_time = time.time()
        epoch_time = end_time - start_time
        
        # 记录历史
        epoch_info = {
            "epoch": epoch + 1,
            "time": epoch_time,
            "train_loss": train_loss,
            "val_loss": val_loss,
            "val_jaccard": val_jaccard,
            "val_dice": val_dice,
            "lr": scheduler.get_last_lr()[0]
        }
        history.append(epoch_info)
        
        # 输出信息
        report = f"Epoch: {epoch+1}/{args.epochs}, Time: {epoch_time:.2f}s, LR: {scheduler.get_last_lr()[0]:.6f}, " \
               f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, " \
               f"Val Jaccard: {val_jaccard:.4f}, Val Dice: {val_dice:.4f}"
        
        print(report)
        
        with open(train_log_filename, "a") as f:
            f.write(report + "\n")
        
        # 保存最佳模型 (基于Dice分数)
        if val_dice > best_val_dice:
            best_val_dice = val_dice
            best_val_loss = val_loss
            torch.save(model.state_dict(), models_folder / args.model_name)
            print("✓ 保存最佳模型 (基于Dice分数)")
            with open(train_log_filename, "a") as f:
                f.write("最佳模型已保存\n")
    
    print(f"\n训练完成! 最佳验证Dice: {best_val_dice:.4f}")
    
    # 测试阶段
    print("\n=== 测试评估 ===")
    model.load_state_dict(torch.load(models_folder / args.model_name))
    model.eval()
    
    test_loss = 0.0
    test_jaccard = 0.0
    test_dice = 0.0
    test_samples = 0
    
    with torch.no_grad():
        for origins, masks in dataloaders["test"]:
            num = origins.size(0)
            origins = origins.to(device)
            masks = masks.to(device)
            
            outputs = model(origins)
            
            if args.use_dice_loss:
                test_loss += criterion(outputs, masks).item() * num
                predictions = torch.argmax(torch.softmax(outputs, dim=1), dim=1).float()
            else:
                softmax = torch.nn.functional.log_softmax(outputs, dim=1)
                test_loss += torch.nn.functional.nll_loss(softmax, masks).item() * num
                predictions = torch.argmax(softmax, dim=1).float()
            
            masks_float = masks.float()
            test_jaccard += jaccard(masks_float, predictions).item() * num
            test_dice += dice(masks_float, predictions).item() * num
            test_samples += num
    
    test_loss = test_loss / test_samples
    test_jaccard = test_jaccard / test_samples
    test_dice = test_dice / test_samples
    
    print(f"\n=== 最终测试结果 ===")
    print(f"测试损失: {test_loss:.4f}")
    print(f"测试Jaccard: {test_jaccard:.4f}")
    print(f"测试Dice: {test_dice:.4f}")
    
    # 保存结果
    final_results = f"\n=== 最终测试结果 ===\n" \
                   f"测试损失: {test_loss:.4f}\n" \
                   f"测试Jaccard: {test_jaccard:.4f}\n" \
                   f"测试Dice: {test_dice:.4f}\n"
    
    with open(train_log_filename, "a") as f:
        f.write(final_results)
    
    # 绘制训练曲线
    if len(history) > 1:
        plt.figure(figsize=(15, 5))
        
        plt.subplot(1, 3, 1)
        epochs = [h["epoch"] for h in history]
        train_losses = [h["train_loss"] for h in history]
        val_losses = [h["val_loss"] for h in history]
        
        plt.plot(epochs, train_losses, 'b-', label='Training Loss')
        plt.plot(epochs, val_losses, 'r-', label='Validation Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.title('Training & Validation Loss')
        
        plt.subplot(1, 3, 2)
        val_dices = [h["val_dice"] for h in history]
        val_jaccards = [h["val_jaccard"] for h in history]
        
        plt.plot(epochs, val_dices, 'g-', label='Dice Score')
        plt.plot(epochs, val_jaccards, 'orange', label='Jaccard Score')
        plt.xlabel('Epoch')
        plt.ylabel('Score')
        plt.legend()
        plt.title('Validation Metrics')
        
        plt.subplot(1, 3, 3)
        lrs = [h["lr"] for h in history]
        plt.plot(epochs, lrs, 'purple', label='Learning Rate')
        plt.xlabel('Epoch')
        plt.ylabel('Learning Rate')
        plt.legend()
        plt.title('Learning Rate Schedule')
        
        plt.tight_layout()
        plt.savefig(f'improved_training_curves.png', dpi=150, bbox_inches='tight')
        print(f"训练曲线已保存到 improved_training_curves.png")
    
    print("改进版训练完成!")

if __name__ == "__main__":
    main()